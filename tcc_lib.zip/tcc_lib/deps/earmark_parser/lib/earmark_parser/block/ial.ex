defmodule EarmarkParser.Block.Ial do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, content: nil, verbatim: ""
end

#  SPDX-License-Identifier: Apache-2.0
