defmodule EarmarkParser.Block.HtmlComment do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, lines: []
end

#  SPDX-License-Identifier: Apache-2.0
