defmodule EarmarkParser.Block.IdDef do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, id: nil, url: nil, title: nil
end

#  SPDX-License-Identifier: Apache-2.0
